public class BreadthFirstSearchAgent implements SearchAgent {

    public BreadthFirstSearchAgent(int sizeX, int sizeY) {
        // ...
    }
    
    public Coordinate move(boolean isExit,
                           boolean hasWallSouth,
                           boolean hasWallNorth,
                           boolean hasWallEast,
                           boolean hasWallWest) {
        // ...
    }

    @Override
    public List<Coordinate> getShortestPath() {
        // ...
    }

}
