public class AStarSearchAgent implements SearchAgent {

    public AStarSearchAgent(int sizeX, int sizeY) {
        // ...
    }
    
    public Coordinate move(boolean isExit,
                           boolean hasWallSouth,
                           boolean hasWallNorth,
                           boolean hasWallEast,
                           boolean hasWallWest,
                           double distance) {
        // ...
    }

    @Override
    public List<Coordinate> getShortestPath() {
        // ...
    }

}
