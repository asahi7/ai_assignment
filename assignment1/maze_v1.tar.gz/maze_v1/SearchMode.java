/**
 * Author: Tsz-Chiu Au and Olzhas Kaiyrakhmet (Nickname: olzhabay) 
 * Email: chiu@unist.ac.kr and olzhabay.i@gmail.com 
 */

public enum SearchMode {
    ASTAR, DFS, BFS
}
